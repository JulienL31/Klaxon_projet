import './bootstrap';
import '../sass/app.scss';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';