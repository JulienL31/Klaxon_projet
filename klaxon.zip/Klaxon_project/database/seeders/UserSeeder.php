<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin principal (modifiable)
        User::updateOrCreate(
            ['email' => 'admin@entreprise.com'],
            [
                'name'     => 'Admin Principal',
                'password' => Hash::make('password'),
                'phone'    => '0600000000',
                'role'     => 'admin',
            ]
        );

        // Quelques comptes "fixes" nommés (pratique pour démos/tests)
        $fixes = [
            ['name' => 'Julien Martin',   'email' => 'julien.martin@entreprise.com'],
            ['name' => 'Camille Leroy',   'email' => 'camille.leroy@entreprise.com'],
            ['name' => 'Nina Dupont',     'email' => 'nina.dupont@entreprise.com'],
            ['name' => 'Omar Bensaïd',    'email' => 'omar.bensaid@entreprise.com'],
            ['name' => 'Léa Bernard',     'email' => 'lea.bernard@entreprise.com'],
            ['name' => 'Hugo Pereira',    'email' => 'hugo.pereira@entreprise.com'],
            ['name' => 'Sofia Moreau',    'email' => 'sofia.moreau@entreprise.com'],
            ['name' => 'Antoine Caron',   'email' => 'antoine.caron@entreprise.com'],
            ['name' => 'Maya Robin',      'email' => 'maya.robin@entreprise.com'],
            ['name' => 'Yanis Gauthier',  'email' => 'yanis.gauthier@entreprise.com'],
        ];

        foreach ($fixes as $u) {
            User::updateOrCreate(
                ['email' => $u['email']],
                [
                    'name'     => $u['name'],
                    'password' => Hash::make('password'),
                    'phone'    => '07' . fake()->numerify('########'),
                    'role'     => 'user',
                ]
            );
        }

        // + 50 utilisateurs aléatoires FR
        User::factory(50)->create();
    }
}
