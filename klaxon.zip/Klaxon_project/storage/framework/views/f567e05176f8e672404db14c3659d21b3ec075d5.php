<header>
<nav class="navbar navbar-klx mb-3">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold"
       href="<?php echo e((auth()->check() && (auth()->user()->role ?? 'user') === 'admin') ? route('admin.index') : route('home')); ?>">
      Touche pas au klaxon
    </a>

    <div class="ms-auto d-flex align-items-center gap-2">
      <?php if(auth()->guard()->guest()): ?>
        <a class="btn btn-chip dark" href="<?php echo e(route('login')); ?>">Connexion</a>
      <?php else: ?>
        <?php if((auth()->user()->role ?? 'user') === 'admin'): ?>
          <a class="btn btn-chip gray" href="<?php echo e(route('admin.users.index')); ?>">Utilisateurs</a>
          <a class="btn btn-chip gray" href="<?php echo e(route('admin.agencies.index')); ?>">Agences</a>
          <a class="btn btn-chip gray" href="<?php echo e(route('admin.trips.index')); ?>">Trajets</a>
        <?php else: ?>
          <a class="btn btn-chip dark" href="<?php echo e(route('trips.create')); ?>">Créer un trajet</a>
        <?php endif; ?>

        <span class="ms-1">Bonjour <?php echo e(auth()->user()->name); ?></span>

        <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline ms-2">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-chip dark">Déconnexion</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</nav>
</header>

<?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/partials/header.blade.php ENDPATH**/ ?>