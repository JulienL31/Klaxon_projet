

<?php $__env->startSection('title','Accueil'); ?>
<?php $__env->startSection('pagetitle','Trajets proposés'); ?>

<?php $__env->startSection('flash'); ?>
  <?php if(session('status')): ?>
    <div class="alert-klx"><?php echo e(session('status')); ?></div>
  <?php endif; ?>
  <?php if(auth()->guard()->guest()): ?>
    <div class="alert-klx">Pour obtenir plus d'informations sur un trajet, veuillez vous connecter</div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="table-box">
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead>
          <tr>
            <th>Départ</th>
            <th>Date</th>
            <th>Heure</th>
            <th>Destination</th>
            <th>Date</th>
            <th>Heure</th>
            <th>Places</th>
            <?php if(auth()->guard()->check()): ?> <th class="text-end">Actions</th> <?php endif; ?>
          </tr>
        </thead>

        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $canManage = auth()->check() && (
                  auth()->id() === $t->author_id ||
                  (auth()->user()->role ?? 'user') === 'admin'
              );
            ?>

            <tr>
              <td><?php echo e($t->from->name); ?></td>
              <td><?php echo e($t->departure_dt->format('d/m/y')); ?></td>
              <td><?php echo e($t->departure_dt->format('H:i')); ?></td>
              <td><?php echo e($t->to->name); ?></td>
              <td><?php echo e($t->arrival_dt->format('d/m/y')); ?></td>
              <td><?php echo e($t->arrival_dt->format('H:i')); ?></td>
              <td><?php echo e($t->seats_free); ?></td>

              <?php if(auth()->guard()->check()): ?>
                <td class="text-end">
                  
                  <button class="btn btn-sm btn-light"
                          data-bs-toggle="modal"
                          data-bs-target="#tripDetails-<?php echo e($t->id); ?>"
                          aria-label="Voir les détails">
                    <i class="bi bi-eye"></i>
                  </button>

                  
                  <?php if($canManage): ?>
                    <a class="btn btn-sm btn-light" href="<?php echo e(route('trips.edit', $t)); ?>" aria-label="Modifier">
                      <i class="bi bi-pencil"></i>
                    </a>

                    <form method="POST"
                          action="<?php echo e(route('trips.destroy', $t)); ?>"
                          class="d-inline"
                          onsubmit="return confirm('Supprimer ce trajet ?')">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button class="btn btn-sm btn-light" aria-label="Supprimer">
                        <i class="bi bi-trash"></i>
                      </button>
                    </form>
                  <?php endif; ?>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="<?php if(auth()->guard()->check()): ?> 8 <?php else: ?> 7 <?php endif; ?>" class="text-center py-5 text-muted">
                Aucun trajet disponible
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
  
  <?php if(auth()->guard()->check()): ?>
    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="modal fade" id="tripDetails-<?php echo e($t->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Détails du trajet</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div class="modal-body">
              <p><strong>Auteur :</strong> <?php echo e($t->contact_name); ?></p>
              <p><strong>Téléphone :</strong> <?php echo e($t->contact_phone ?? '—'); ?></p>
              <p><strong>Email :</strong> <?php echo e($t->contact_email); ?></p>
              <p><strong>Nombre total de places :</strong> <?php echo e($t->seats_total); ?></p>
            </div>
            <div class="modal-footer">
              <button class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/home/index.blade.php ENDPATH**/ ?>