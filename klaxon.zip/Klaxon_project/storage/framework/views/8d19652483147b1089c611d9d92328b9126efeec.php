
<?php $__env->startSection('title','Trajets'); ?>
<?php $__env->startSection('pagetitle','Trajets'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?> <div class="alert-klx mb-3"><?php echo e(session('status')); ?></div> <?php endif; ?>

  <div class="table-box">
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead>
          <tr>
            <th>Départ</th><th>Date</th><th>Heure</th>
            <th>Destination</th><th>Date</th><th>Heure</th>
            <th>Places (libres/total)</th><th>Auteur</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($t->from->name); ?></td>
              <td><?php echo e($t->departure_dt->format('d/m/y')); ?></td>
              <td><?php echo e($t->departure_dt->format('H:i')); ?></td>
              <td><?php echo e($t->to->name); ?></td>
              <td><?php echo e($t->arrival_dt->format('d/m/y')); ?></td>
              <td><?php echo e($t->arrival_dt->format('H:i')); ?></td>
              <td><?php echo e($t->seats_free); ?> / <?php echo e($t->seats_total); ?></td>
              <td><?php echo e($t->author->name ?? $t->contact_name); ?></td>
              <td class="text-end">
                <form method="POST" action="<?php echo e(route('admin.trips.destroy',$t)); ?>"
                      onsubmit="return confirm('Supprimer ce trajet ?')" class="d-inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-light"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="9" class="text-center py-5 text-muted">Aucun trajet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/admin/trips/index.blade.php ENDPATH**/ ?>