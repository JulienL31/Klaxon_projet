
<?php $__env->startSection('title','Agences'); ?>
<?php $__env->startSection('pagetitle','Agences'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?> <div class="alert-klx mb-3"><?php echo e(session('status')); ?></div> <?php endif; ?>

  <div class="mb-3">
    <a class="btn btn-primary" href="<?php echo e(route('admin.agencies.create')); ?>">Créer une agence</a>
  </div>

  <div class="table-box">
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead><tr><th>ID</th><th>Nom</th><th class="text-end">Actions</th></tr></thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($a->id); ?></td>
              <td><?php echo e($a->name); ?></td>
              <td class="text-end">
                <a class="btn btn-sm btn-light" href="<?php echo e(route('admin.agencies.edit',$a)); ?>"><i class="bi bi-pencil"></i></a>
                <form class="d-inline" method="POST" action="<?php echo e(route('admin.agencies.destroy',$a)); ?>" onsubmit="return confirm('Supprimer cette agence ?')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-light"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="text-center py-5 text-muted">Aucune agence</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/admin/agencies/index.blade.php ENDPATH**/ ?>