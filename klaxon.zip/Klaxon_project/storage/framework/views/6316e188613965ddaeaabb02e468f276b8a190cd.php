<footer class="text-center py-4 small text-muted">
  © 2024 - CENEF - MVC PHP
</footer>
<?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/partials/footer.blade.php ENDPATH**/ ?>