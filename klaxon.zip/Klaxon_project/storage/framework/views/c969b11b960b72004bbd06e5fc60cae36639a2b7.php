
<?php $__env->startSection('title','Utilisateurs'); ?>
<?php $__env->startSection('pagetitle','Utilisateurs'); ?>

<?php $__env->startSection('content'); ?>
  <div class="table-box">
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead><tr><th>ID</th><th>Nom</th><th>Email</th><th>Rôle</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($u->id); ?></td>
              <td><?php echo e($u->name); ?></td>
              <td><?php echo e($u->email); ?></td>
              <td><?php echo e($u->role); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Azshira\Documents\GitHub\Klaxon_project\Klaxon_project\resources\views/admin/users/index.blade.php ENDPATH**/ ?>